const express = require("express");
const { MongoClient, ObjectId } = require("mongodb");
const app = express();
const url = "mongodb://localhost:27017/";
const port = 3000;
let dbConnection;

app.set("view engine", "ejs");

app.use(express.static(__dirname + "/public"));
app.use(express.urlencoded({ extended: true }));

async function startServer() {
  await connectToMongoDB();
  app.listen(port, () => {
    console.log(`Server listening at http://localhost:${port}`);
  });
}

async function connectToMongoDB() {
  try {
    const client = await MongoClient.connect(url);
    console.log(`Connected to database.`);
    dbConnection = client.db('kol2');
  } catch (err) {
    console.error(`Wystapil bład: ${err}`);
  }
}

startServer();

app.get('/', async (req,res) => {
    try{
        let cars;
        const marka = req.query.marka || '';
        const model = req.query.model || '';
        const rok_produkcji = parseInt(req.query.rok_produkcji);
        const kolor = req.query.kolor || '';

        if(rok_produkcji > 0){
            cars = await dbConnection.collection('cars').find().ToArray();
        } else if(kolor != ''){
            cars = await dbConnection.collection('cars').find().toArray();
        } else if(marka != ''){
            cars = await dbConnection.collection('cars').find().toArray();
        } else if(model != ''){
            cars = await dbConnection.collection('cars').find().toArray();
        } else {
            cars = await dbConnection.collection('cars').find().toArray();
        }

        res.render(`${__dirname}/public/index`, {cars});
    } catch(err){
        console.error(`Wystąpił błąd: ${err}`);
        res.status(500).json({error: 'Błąd pobierania dantych'});
    }
});


// dodawanie auta
app.get('/add', async (req, res) => {
    res.render(__dirname + '/public/add.ejs');
});

app.post('/add', async (req,res) => {
    try{
        const {marka, model, moc, kolor, rok_produkcji} = req.body;
        const _moc = parseInt(moc);
        const _rok_produkcji = parseInt(rok_produkcji);

        if(!marka || marka.trim() === ''){
            throw new Error('Marka jest wymagana');
        }
        if(!model || model.trim() === ''){
            throw new Error('Model jest wymagany');
        }
        if(!kolor || kolor.trim() === ''){
            throw new Error('Kolor jest wymagany');
        }
        if(isNaN(_moc) || _moc <= 0){
            throw new Error('Moc musi byc wieksza od zera i musi byc liczba !');
        }
        if(isNaN(_rok_produkcji) || _rok_produkcji <= 0){
            throw new Error('Rok produkcji musi byc wiekszy od zera i musi byc liczba !');
        }
        
        const collection = dbConnection.collection('cars');

        const lastId = await collection.find().sort({id: -1}).limit(1).toArray();
        const nextId = lastId.length > 0 ? lastId[0].id + 1 : 1;

        await collection.insertOne({id: nextId, marka, model, moc: _moc, kolor, rok_produkcji: _rok_produkcji});
        res.redirect('/');
    } catch(err){
        console.log(`Błąd: ${err}`);
        res.status(400).json({error: err.message});
    }
});

// filtrowanie auta po mocy
app.get('/moc', async (req, res) => {
    res.render(__dirname + '/public/moc.ejs', {moc: '', cars: []});
});

app.post('/moc', async (req, res) => {
    try{
        const { moc } = req.body;
        const _moc = parseInt(moc);
        let cars = [];

        if(isNaN(_moc) || _moc <= 0){
            throw new Error('Moc musi byc wieksza od zera i musi byc liczba!');
        }
        
        cars = await dbConnection.collection('cars').find({moc: {$gt: _moc}}).toArray();
        res.render(__dirname + '/public/moc.ejs', { moc: _moc, cars });

    } catch(err){
        console.error(`Błąd: ${err}`);
        res.status(400).json({error: err.message});
    }
});

// szukanie auta po marce
app.get('/marka', async (req,res) => {
    res.render(__dirname + '/public/marka.ejs', {marka: '', cars: []});
});

app.post('/marka', async (req, res) => {
    try{
        const { marka } = req.body;
        const searchMarka = marka;
        if(!searchMarka || searchMarka === ''){
            throw new Error('Pole kolor jest wymagane!');
        }
        let cars;
        cars = await dbConnection.collection('cars').find({marka: searchMarka}).toArray();
        res.render(__dirname + '/public/marka.ejs', {marka: searchMarka, cars});
    } catch(err){
        console.error(`Błąd: ${err}`);
        res.status(400).json({error: err.message});
    }
});

// edytowanie auta
app.get('/edit/:id', async (req, res) => {
    try{
        const id = req.params.id;
        const collection = dbConnection.collection('cars'); 
        const car = await collection.findOne({_id: new ObjectId(id)});
        res.render(`${__dirname}/public/edit`, { car });
    } catch(err){
        console.error(`Błąd: ${err}`);
        res.status(500).json({error: err.message});
    }
});

app.post('/edit/:id', async (req, res) => {
    try{
        const id = req.params.id;
        const collection = dbConnection.collection('cars');

        const marka = req.body.marka;
        const model = req.body.model;
        const moc = parseInt(req.body.moc);
        const kolor = req.body.kolor;
        const rok_produkcji = parseInt(req.body.rok_produkcji);

        if(!marka || marka === ''){
            throw new Error('Marka nie moze byc pusta!');
        }
        if(!model || model === ''){
            throw new Error('Model nie moze byc pusty!');
        }
        if(!kolor || kolor === ''){
            throw new Error('Kolor nie moze byc pusty!');
        }
        if(isNaN(moc) || moc <= 0){
            throw new Error('Moc musi byc liczba i musi bc wieksza od zera!');
        }
        if(isNaN(rok_produkcji) || rok_produkcji <= 0){
            throw new Error('Rok produkcji musi byc liczba i musi bc wieksza od zera!');
        }

        const update = {
            $set:{
                marka: marka,
                model: model,
                moc: moc,
                kolor: kolor,
                rok_produkcji: rok_produkcji
            }
        };

        await collection.updateOne({_id: new ObjectId(id) }, update);
        res.redirect('/');

    } catch(err){
        console.error(`Błąd: ${err}`);
        res.status(400).json({error: err.message});
    }   
});

// usuwanie samochodu
app.get('/delete/:id', async (req, res) => {
    try{
        const id = req.params.id;
        const collection = dbConnection.collection('cars');
        const car = await collection.findOne( { _id: new ObjectId(id) } );
        res.render(`${__dirname}/public/delete`, {car});
    } catch(err){
        console.error(`Błąd: ${err}`);
        res.status(500),json({error: err.message});
    }
});

app.post('/delete/:id', async (req, res) => {
    try{
        const id = req.params.id;
        const collection = dbConnection.collection('cars');
        await collection.deleteOne( { _id: new ObjectId(id) } );
        res.redirect('/');
    } catch(err){
        console.error(`Błąd: ${err}`);
        res.status(400).json({error: err.message});
    }
});